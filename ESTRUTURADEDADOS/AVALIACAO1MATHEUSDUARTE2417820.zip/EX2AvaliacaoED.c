#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct lista{
  int valor;
  struct lista* prox;
}Lista;

typedef struct fila{
    Lista* ini;
    Lista* fim;
}Fila;

typedef struct pilha{
    Lista* topo;    
}Pilha;

void push(Pilha* P, int info){
  Lista* novo = (Lista*) malloc(sizeof(Lista));
  novo->valor = info;
  novo->prox = P->topo;
  P->topo = novo;
}

int pop(Pilha* P){
  int retorno = 0;
  Lista* aux = P->topo;
  if(aux!=NULL){
    P->topo = aux->prox;
    retorno = aux->valor;
    free(aux);
    return retorno;
  }
}

void removeFila(Fila* F){
  Lista* aux = F->ini;
  
  // Verica Fila vazia
  if(F->ini!=NULL){
    F->ini = aux->prox;
    free(aux);
    if(F->ini == NULL)
      F->fim = NULL;
  }
  
}

void insereFila(Fila* F, int info){
   Lista* novo = (Lista*) malloc(sizeof(Lista));
  novo->valor = info;
  novo->prox = NULL;

  //Verifica fila vazia
  if (F->ini ==NULL){
    F->ini = novo;
    F->fim = novo;
  }else{
    F->fim->prox = novo;
    F->fim = novo;
  }
}
void imprime(Fila* F){
  Lista* aux = F->ini;
  while (aux!=NULL){
    printf("%d ", aux->valor);
    aux=aux->prox;
  }
  printf("\n");
}

void inverte_kprimeiros(Fila* F, int k){

    Lista* aux = F->ini;
    Lista* aux2 = F->ini;
    Lista* aux3= F -> ini;
    

    while (aux!= NULL)
    {
        
           if (aux->valor == k)
            {
              
                printf("\n %d ", aux->valor);

            }
        
        
        aux= aux->prox;
    }

    while (aux2!= NULL)
    {
        if (aux2->valor < k)
        {
            printf(" %d ", aux2->valor);

        }
        
        aux2= aux2->prox;
    }
    
    while (aux3!=NULL)
    {   
        if (aux3->valor > k)
        {
            printf(" %d ", aux3->valor);
        }
        
        aux3= aux3->prox;
    }
    
    
   
}

/* 
Desenvolver uma função que inverte os k primeiros
elementos de uma Fila
Ex:
Entrada:
k = 3
Fila: 1 2 3 4 5
Saída: 
3 2 1 4 5
*/

int main(){   

  //Cria a Fila
  Fila* F = (Fila*) malloc(sizeof(Fila));
  F->ini = NULL;
  F->fim = NULL; 
  insereFila(F, 1);
  insereFila(F, 2);
  insereFila(F, 3);
  insereFila(F, 4);
  insereFila(F, 5);
  imprime(F);

 inverte_kprimeiros(F, 1);
 //imprime(F);
 inverte_kprimeiros(F, 2);
 //imprime(F);
 inverte_kprimeiros(F, 3);
 //imprime(F);
 inverte_kprimeiros(F, 4);
 //imprime(F);
 inverte_kprimeiros(F, 5);
 //imprime(F);
 
  return (0);
  }