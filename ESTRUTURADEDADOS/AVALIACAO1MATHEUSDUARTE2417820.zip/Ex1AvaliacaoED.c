#include <stdio.h>
#include <stdlib.h>

typedef struct lista {
  int valor;
  struct lista *prox;
  struct lista *ant;
} ListaD;

ListaD *insereIni(ListaD *L, int info) {
  ListaD *novo = (ListaD *)malloc(sizeof(ListaD));
  novo->valor = info;
  novo->prox = L;
  novo->ant = NULL;
  if (L != NULL)
    L->ant = novo;
  return novo;
}

ListaD *insereFim(ListaD *L, int info) {
  ListaD *novo = (ListaD *)malloc(sizeof(ListaD));
  novo->valor = info;
  novo->prox = NULL;

  if (L == NULL) {
    novo->ant = NULL;
    return novo;
  } else {
    ListaD *aux = L;
    while (aux->prox != NULL) {
      aux = aux->prox;
    }
    novo->ant = aux;
    aux->prox = novo;
  }
  return L;
}

void imprime(ListaD *L) {
  printf("Lista:\n");
  while (L != NULL) {
    printf("%d\n", L->valor);
    L = L->prox;
  }
}
ListaD *liberaLista(ListaD *L) {
  ListaD *aux = L;
  while (L != NULL) {
    L = L->prox;
    free(aux);
    aux = L;
  }
  return NULL;
}

ListaD* trocaValores(ListaD* L, int M, int N){


    ListaD* aux1 = L;
    ListaD* aux2 = L;
    int aux;
    int auxv1=0;
    int auxv2=0;
    
    while (aux1 != NULL && aux1->valor != M)
    {
        aux1 = aux1->prox;  

    }

    while (aux2 != NULL && aux2->valor != N)
    {
        aux2 = aux2->prox;  
        
    }

    auxv1 = aux1-> valor;
    auxv2 = aux2-> valor;

      //CASO aux começo
      if (aux1->prox->ant == NULL) 
      { 
        aux1 = aux2;

        while (aux2->ant != NULL)
        {
          aux2 = aux2 -> ant;
        }
        
          aux2 -> valor = auxv2;

          aux1 ->valor = auxv1;
      }

        if (aux2->prox->ant == NULL)
        {
          aux2 = aux1;

          while (aux1->ant != NULL)
        {
          aux1 = aux1 -> ant;
        }
        
          aux1 -> valor = auxv1;

          aux2 -> valor = auxv2;
        }
          //CASO aux fim
          if (aux1->prox==NULL)
          {
            aux1 = aux2;
            while (aux2->prox != NULL)
            {
              aux2 = aux2-> prox;
            }
            
              aux1-> valor = auxv1;
              aux2->valor = auxv2;
          }

            if (aux2->prox == NULL)
            {
              aux2 = aux1;
              while (aux1->prox != NULL)
              {
                aux1 = aux1-> prox;
              }
            
                aux1-> valor = auxv1;
                aux2-> valor = auxv2;
            }

    //CASO PERTO    
    if (aux1->prox->ant == aux2  && aux2->ant->prox == aux1)
    {
        aux1->ant->prox ->valor = auxv2;
        aux2->ant->prox -> valor = auxv1;
    }

    //Caso Generico
    aux = aux1->valor;
    aux1->valor = aux2->valor;
    aux2->valor = aux;

  return L;
}
/*
Escreva uma função em C para trocar os valores m e n de uma lista
duplamente encadeada (m e n podem valores definidos pelo usuario).
*/
int main(void) {
  ListaD *L = NULL;
  // caso 1
  L = insereIni(L, 1);
  L = insereFim(L, 3);
  L = insereFim(L, 5);
  L = insereFim(L, 7);
  L = insereFim(L, 11);
  L = insereFim(L, 13);
  L = insereFim(L, 17);
  L = insereFim(L, 19);
  imprime(L);

  L = trocaValores(L,11,13);
  imprime(L);
  L = trocaValores(L,1,5);
  imprime(L);
  L = trocaValores(L,5,7);
  imprime(L);
  L = trocaValores(L,7,19);
  imprime(L);
  L = trocaValores(L,13,25);
  imprime(L);

  L = liberaLista(L);
}